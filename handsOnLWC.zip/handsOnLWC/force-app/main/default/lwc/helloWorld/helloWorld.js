import { LightningElement } from 'lwc';
export default class HelloWorld extends LightningElement {
//   greeting = 'World';
//   changeHandler(event) {
//     this.greeting = event.target.value;
//   }
obj = {
	Name: '',
	Email: ''
  };
  changeHandler(event) {
    let id = event.target.label;  

    let value = event.target.value;

    this.obj[id] = value;

    this.obj = {...this.obj};

    console.log(this.obj[id]);
  }
}
